"""
app.py
======
Telegram Chatbot entry‑point using aiogram 2.x and Groq LLM.

Original bot used openai.ChatCompletion (deprecated).
This version replaces it with the Groq client using:
  - llama-3.1-8b-instant  : fast responses, 8 k context.
  - llama-3.3-70b-versatile: richer answers when needed (swap model_name).

Token‑limit awareness
---------------------
* The Groq context window for llama‑3.1‑8b‑instant is 8 192 tokens.
* We store only the *last assistant response* in `reference.response` to
  avoid blowing the context on long conversations.
* For production use the Mem0 utility provides a better memory strategy.

Run locally:
    export GROQ_API_KEY=...
    export TELEGRAM_BOT_TOKEN=...
    python app.py
"""

import os
import logging
from aiogram import Bot, Dispatcher, executor, types
from groq import Groq

# ── Logging ───────────────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s",
)
logger = logging.getLogger(__name__)

# ── API clients ───────────────────────────────────────────────────────────────
GROQ_API_KEY     = os.getenv("GROQ_API_KEY")
TELEGRAM_TOKEN   = os.getenv("TELEGRAM_BOT_TOKEN")

groq_client = Groq(api_key=GROQ_API_KEY)

# Model choices:
#   "llama-3.1-8b-instant"    – 8 k ctx, fastest
#   "llama-3.3-70b-versatile" – 32 k ctx, highest quality
MODEL_NAME = "llama-3.1-8b-instant"

# ── Reference memory ──────────────────────────────────────────────────────────

class Reference:
    """Stores the most recent assistant reply for single‑turn context."""
    def __init__(self) -> None:
        self.response: str = ""


reference = Reference()
bot        = Bot(token=TELEGRAM_TOKEN)
dispatcher = Dispatcher(bot)


# ── Helpers ───────────────────────────────────────────────────────────────────

def clear_past() -> None:
    """Reset the rolling conversation reference."""
    reference.response = ""


# ── Handlers ──────────────────────────────────────────────────────────────────

@dispatcher.message_handler(commands=["clear"])
async def clear(message: types.Message) -> None:
    """Clear the conversation context."""
    clear_past()
    await message.reply("Context cleared.  Starting a fresh conversation.")


@dispatcher.message_handler(commands=["start"])
async def welcome(message: types.Message) -> None:
    """/start — greet the user."""
    await message.reply(
        "Hi!  I am your AI assistant powered by Groq + LLaMA.
"
        "Send me any message to chat.  Use /clear to reset context, /help for more info."
    )


@dispatcher.message_handler(commands=["help"])
async def helper(message: types.Message) -> None:
    """/help — show available commands."""
    await message.reply(
        "Available commands:
"
        "  /start — Start or restart the conversation.
"
        "  /clear — Wipe conversation history.
"
        "  /help  — Show this menu.

"
        "Just type a message to chat with the LLaMA model via Groq!"
    )


@dispatcher.message_handler()
async def chat_handler(message: types.Message) -> None:
    """
    Handle any free‑text message.

    Sends the user message plus the last assistant reply (rolling 1‑turn memory)
    to the Groq API and echoes the response back to Telegram.

    Token‑limit guard: if the previous response is very long we truncate it to
    keep the total prompt under ~6 000 tokens (conservative for 8 k window).
    """
    user_text = message.text
    logger.info("User (%s): %s", message.from_user.username, user_text)

    # Truncate previous response if it exceeds ~1 500 characters to stay safe
    prev_context = reference.response[:1500] if reference.response else ""

    messages = []
    if prev_context:
        messages.append({"role": "assistant", "content": prev_context})
    messages.append({"role": "user", "content": user_text})

    try:
        completion = groq_client.chat.completions.create(
            model=MODEL_NAME,
            messages=messages,
            max_tokens=1024,      # cap reply length to control costs
            temperature=0.7,
        )
        reply = completion.choices[0].message.content
    except Exception as exc:
        logger.exception("Groq API error: %s", exc)
        reply = "Sorry, I encountered an error.  Please try again."

    reference.response = reply
    logger.info("Bot: %s", reply[:120])
    await bot.send_message(chat_id=message.chat.id, text=reply)


# ── Entry‑point ───────────────────────────────────────────────────────────────

if __name__ == "__main__":
    logger.info("Starting Telegram bot with model: %s", MODEL_NAME)
    executor.start_polling(dispatcher, skip_updates=False)

"""
main.py  (all-utils)
=====================
Orchestrates all utility demos in sequence:
  1. Pydantic request/response models
  2. Query validation & transformation
  3. Logging
  4. Mem0 long‑term memory
"""

from utilities.pydantic_models import demo as pydantic_demo
from utilities.query_validation_transformation import handle_query
from utilities.logging_example import run_logging_demo
from utilities.mem0_example import run_observability_demo


def main() -> None:
    print("=" * 60)
    print("PHASE A — Pydantic Models")
    print("=" * 60)
    pydantic_demo()

    print("
" + "=" * 60)
    print("PHASE B — Query Validation & Transformation")
    print("=" * 60)
    result = handle_query("Find the latest laptop deals")
    for k, v in result.items():
        print(f"  {k:12s}: {v}")

    print("
" + "=" * 60)
    print("PHASE C — Logging")
    print("=" * 60)
    run_logging_demo()

    print("
" + "=" * 60)
    print("PHASE D — Mem0 Observability")
    print("=" * 60)
    run_observability_demo()


if __name__ == "__main__":
    main()

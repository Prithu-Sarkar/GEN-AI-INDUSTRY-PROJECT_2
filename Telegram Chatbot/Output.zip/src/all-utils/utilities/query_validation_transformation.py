"""
query_validation_transformation.py
====================================
Validates and transforms raw user queries before they are sent to an LLM
or a vector‑store retriever.

GenAI rationale
---------------
* Removes stop‑words  → shorter prompts → lower token cost.
* Synonym mapping     → stable cache keys across semantically‑identical queries.
* Pattern guard       → rejects prompt‑injection attempts and garbage input.
* Signature field     → used as a deterministic cache key to skip redundant LLM calls.
"""

import re
from typing import Dict


# ── Constants ─────────────────────────────────────────────────────────────────

# Only allow safe printable characters (block prompt injection via weird Unicode)
ALLOWED_QUERY_PATTERN = re.compile(r"^[a-zA-Z0-9\s?@#\-_.,'\"()]+$")

# High‑frequency words that add noise to retrieval but carry little semantics
STOP_WORDS = {"the", "is", "and", "or", "for", "a", "an", "to"}

# Map colloquial terms to canonical forms for consistent cache keys
SYNONYMS = {
    "buy": "purchase",
    "find": "search",
    "latest": "recent",
}


# ── Validation ────────────────────────────────────────────────────────────────

def validate_query(query: str) -> bool:
    """
    Raise ValueError if the query is too short or contains unsafe characters.

    Parameters
    ----------
    query : str  Raw query string from the user.

    Returns
    -------
    bool  True if validation passes.
    """
    if not query or len(query.strip()) < 3:
        raise ValueError("Query must be at least 3 characters long.")
    if not ALLOWED_QUERY_PATTERN.match(query):
        raise ValueError("Query contains invalid characters.")
    return True


# ── Transformation ────────────────────────────────────────────────────────────

def transform_query(query: str) -> Dict[str, str]:
    """
    Normalise, stop‑word filter, and synonym‑map a raw query.

    Returns a dict with four keys:
        original   – the unmodified input
        normalized – lower‑cased, de‑duped whitespace
        cleaned    – stop‑words removed, synonyms applied
        signature  – underscore‑delimited form used as cache key
    """
    normalized = query.strip().lower()
    normalized = re.sub(r"\s+", " ", normalized)

    tokens = normalized.split()
    tokens = [SYNONYMS.get(tok, tok) for tok in tokens if tok not in STOP_WORDS]
    cleaned = " ".join(tokens)

    return {
        "original": query,
        "normalized": normalized,
        "cleaned": cleaned,
        "signature": cleaned.replace(" ", "_"),
    }


# ── Public entry‑point ────────────────────────────────────────────────────────

def handle_query(query: str) -> Dict[str, str]:
    """Validate then transform a query.  Raises ValueError on bad input."""
    validate_query(query)
    return transform_query(query)

"""
pydantic_models.py
==================
Pydantic v2 data models for the Telegram Chatbot pipeline.

In a GenAI context:
  - SearchRequest  → validated input arriving from the Telegram bot / LLM tool‑call.
  - SearchResponse → structured output returned to the caller / downstream chain.
"""

from pydantic import BaseModel, EmailStr, Field, field_validator
from datetime import datetime
from typing import Optional, List


# ── Input Schema ──────────────────────────────────────────────────────────────
class SearchRequest(BaseModel):
    """Represents a validated search request from the user."""

    user_id: str = Field(..., min_length=3, max_length=50, description="Unique user identifier")
    email: EmailStr = Field(..., description="Verified e‑mail of the requester")
    query: str = Field(..., min_length=1, max_length=200, description="Search query text")
    tags: Optional[List[str]] = Field(default_factory=list, description="Optional categorisation tags")

    @field_validator("query")
    @classmethod
    def query_must_not_be_empty(cls, value: str) -> str:
        """Reject queries that are only whitespace."""
        if not value.strip():
            raise ValueError("Query must not be empty or whitespace")
        return value.strip()


# ── Output Schema ─────────────────────────────────────────────────────────────
class SearchResponse(BaseModel):
    """Represents the validated response returned from the search handler."""

    status: str = Field(..., description="'success' or 'error'")
    message: str = Field(..., description="Human‑readable status message")
    result_count: int = Field(0, ge=0, description="Number of results returned")
    results: List[dict] = Field(default_factory=list, description="List of result payloads")
    processed_at: datetime = Field(default_factory=datetime.utcnow, description="UTC timestamp")


# ── Factory helper ────────────────────────────────────────────────────────────
def build_search_response(request: SearchRequest) -> SearchResponse:
    """
    Simulate a search and wrap results in a validated SearchResponse.

    In a real pipeline this would call a vector DB or external search API.
    """
    example_results = [
        {"id": 1, "title": "Example item", "query": request.query},
    ]
    return SearchResponse(
        status="success",
        message=f"Search completed for user {request.user_id}",
        result_count=len(example_results),
        results=example_results,
    )


# ── Quick smoke‑test ──────────────────────────────────────────────────────────
def demo() -> None:
    """Run a quick validation demo."""
    payload = {
        "user_id": "user123",
        "email": "user@example.com",
        "query": "search for utilities",
        "tags": ["example", "demo"],
    }
    req = SearchRequest(**payload)
    resp = build_search_response(req)
    print("Request model:")
    print(req.model_dump_json(indent=2))
    print()
    print("Response model:")
    print(resp.model_dump_json(indent=2))


if __name__ == "__main__":
    demo()

"""
mem0_example.py
===============
Demonstrates long‑term memory management with Mem0 backed by ChromaDB
and the Groq LLM (llama‑3.1‑8b‑instant).

GenAI rationale
---------------
LLMs are stateless.  Mem0 adds a persistent, semantically‑searchable
memory layer so the chatbot can:
  * Remember user preferences across sessions.
  * Detect and resolve conflicting user facts (e.g. AWS → GCP migration).
  * Inject only the *relevant* memories into each prompt (RAG for preferences).
  * Provide an audit trail of how a user\'s profile evolved over time.
"""

import os
from mem0 import Memory


def run_observability_demo() -> None:
    """
    Full lifecycle: store → update → inspect history → semantic search.

    Requires GROQ_API_KEY in the environment (set via Colab secrets or os.environ).
    Uses ChromaDB as the local free vector store (no external service needed).
    """

    # ── Configuration: Groq LLM + local ChromaDB vector store ────────────────
    config = {
        "vector_store": {
            "provider": "chroma",
            "config": {
                "collection_name": "telegram_bot_demo",
                "path": "telegram_chatbot/all-utils/db",  # persisted locally
            },
        },
        "llm": {
            "provider": "groq",
            "config": {
                # llama‑3.1‑8b‑instant: fast, 8 k context — good for memory ops
                "model": "llama-3.1-8b-instant",
                "temperature": 0,
                "api_key": os.environ.get("GROQ_API_KEY"),
            },
        },
        # Embeddings: use a free local sentence‑transformers model via HuggingFace
        "embedder": {
            "provider": "huggingface",
            "config": {"model": "multi-qa-MiniLM-L6-cos-v1"},
        },
    }

    # ── Initialise the memory object ──────────────────────────────────────────
    print()
    print("[Mem0] Initialising memory store …")
    m = Memory.from_config(config)
    user_id = "colab_demo_user"

    # ── Step 1: Store an initial preference ──────────────────────────────────
    print()
    print("--- [Step 1] Storing initial preference ---")
    result = m.add("I prefer using FastAPI and AWS for my projects.", user_id=user_id)
    print(f"Result: {result}")

    # Robust ID extraction (Mem0 API returns either list or dict depending on version)
    mem_id = None
    if isinstance(result, list) and result:
        mem_id = result[0].get("id")
    elif isinstance(result, dict):
        res_list = result.get("results") or result.get("memories") or []
        if res_list:
            mem_id = res_list[0].get("id")

    # ── Step 2: Update the preference (triggers LLM‑driven conflict resolution)
    print()
    print("--- [Step 2] Updating preference (triggers change detection) ---")
    m.add(
        "Actually, I have decided to migrate all my projects to Google Cloud.",
        user_id=user_id,
    )

    # ── Step 3: Observability — inspect the evolution history ─────────────────
    print()
    print("--- [Step 3] OBSERVABILITY — Memory evolution report ---")
    if mem_id:
        history = m.history(memory_id=mem_id)
        for entry in history:
            event = entry.get("event", "unknown")
            old = entry.get("old_memory") or entry.get("old_value") or "Initial"
            new = entry.get("memory") or entry.get("new_value", "")
            print(f"  Event : {event}")
            print(f"  Old   : {old}")
            print(f"  New   : {new}")
            print("  " + "-" * 40)
    else:
        print("  Note: memory ID not captured — check the db folder for persisted data.")

    # ── Step 4: Semantic search using the updated profile ─────────────────────
    print()
    print("--- [Step 4] Semantic search: 'What is my deployment preference?' ---")
    search_results = m.search(
        "What is my deployment preference?",
        filters={"user_id": user_id},
    )

    # Normalise search result format across Mem0 versions
    memories = (
        search_results.get("results")
        if isinstance(search_results, dict)
        else search_results
    )
    if memories:
        for res in memories:
            val = res.get("memory") or res.get("payload", {}).get("value")
            print(f"  Observed Memory : {val}  (Score: {res.get('score')})")
    else:
        print("  No memories found for this user.")


if __name__ == "__main__":
    run_observability_demo()

"""
logging_example.py
==================
Provides a dual‑sink application logger (stdout + file) for the pipeline.

GenAI rationale
---------------
LLM calls are non‑deterministic.  Without structured logs you cannot:
  * Audit what prompt caused a hallucination.
  * Measure p99 latency of LLM API calls.
  * Track token usage for cost management.
  * Catch API rate‑limit / context‑overflow errors.
"""

import logging
import sys


# ── Logger factory ────────────────────────────────────────────────────────────

def get_app_logger(name: str = __name__) -> logging.Logger:
    """
    Return a named logger with a console handler (INFO+) and a file handler (DEBUG+).

    Idempotent: calling twice with the same name returns the cached logger.

    Parameters
    ----------
    name : str  Logger name, typically the module name.
    """
    logger = logging.getLogger(name)
    if logger.handlers:          # already configured — avoid duplicate handlers
        return logger

    logger.setLevel(logging.DEBUG)

    # Console — INFO and above for human readability during development
    console = logging.StreamHandler(sys.stdout)
    console.setLevel(logging.INFO)
    console.setFormatter(logging.Formatter(
        "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    ))

    # File — DEBUG and above for full audit trail
    file_h = logging.FileHandler(
        "telegram_chatbot/all-utils/utility_logging_example.log", encoding="utf-8"
    )
    file_h.setLevel(logging.DEBUG)
    file_h.setFormatter(logging.Formatter(
        "%(asctime)s | %(levelname)s | %(name)s | %(message)s"
    ))

    logger.addHandler(console)
    logger.addHandler(file_h)
    logger.propagate = False     # prevent duplicate messages from root logger
    return logger


# ── Demo function ─────────────────────────────────────────────────────────────

def run_logging_demo() -> None:
    """Exercise every log level to verify the logger is wired correctly."""
    logger = get_app_logger("utility_logger")

    logger.debug("Debugging values: %s", {"step": 1, "status": "starting"})
    logger.info("Application example started.")
    logger.warning("This is a warning example for the logging utility.")

    try:
        _ = 10 / 0
    except ZeroDivisionError:
        logger.exception("An exception occurred while dividing by zero.")

    logger.info("Logging demo finished.")


if __name__ == "__main__":
    run_logging_demo()
